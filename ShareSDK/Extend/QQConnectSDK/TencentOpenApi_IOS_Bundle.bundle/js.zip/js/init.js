/**
 * 接口命名空间
 */
window.tencent = tencent = {};
/**
 * 本地接口命名空间
 */
window.local =local = {};
/**
 * 常量命名空间
 */
window.constant = {};
/**
 * 工具类命名空间
 */
window.utils = {};